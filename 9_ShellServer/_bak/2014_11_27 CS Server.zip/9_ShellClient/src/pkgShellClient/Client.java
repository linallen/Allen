package pkgShellClient;

import java.net.Socket;

import pkgCommon.AAI_Module;

/**
 * AAI Client.
 * 
 * @author Allen Lin, 25 Nov 2014
 */
public class Client extends AAI_Module {
	private Sender m_sender;
	private Receiver m_receiver;

	public Client(String ip, int port) throws Throwable {
		Socket socket = null;
		try {
			// 1. connect to server
			socket = new Socket(ip, port);
			outStreamln("Connected to server " + ip + ":" + port + ".");
			// 2. start "sender" and "receiver" threads to talk with server
			m_sender = new Sender(socket.getOutputStream());
			m_receiver = new Receiver(socket.getInputStream());
			m_sender.debug(true);
			m_receiver.debug(true);
			Thread threadSender = m_sender.start();
			Thread threadReceiver = m_receiver.start();
			// 3. wait for sender and receiver to stop. sender stops first.
			threadSender.join();
			m_receiver.stop(true);
			threadReceiver.join();
		} catch (Exception e) {
			printException(name(), e);
			return;
		} finally {
			if ((socket != null) && !socket.isClosed()) {
				socket.close();
			}
		}
		dbgPrint("Thread " + name() + " terminated normally.\n");
	}

	public static void main(String[] args) throws Throwable {
		new Client("127.0.0.1", 9999);
	}
}