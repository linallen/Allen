package pkgShellClient;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.Scanner;

public class Client_ok1 {
	/** server ip. TODO: be configured by starting parameters */
	private static String m_svrIP = "127.0.0.1";

	/** server port */
	private static int m_port = 9999;

	/** client command */
	String m_command = new String();

	@SuppressWarnings("resource")
	public void run() {
		try {
			Socket socket = new Socket(m_svrIP, m_port);
			Scanner scan = new Scanner(System.in);

			OutputStream outputStream = socket.getOutputStream();
			InputStream inputStream = socket.getInputStream();

			for (;; m_command = "") {
				System.out.print("AAI> ");
				// 1. read command from user input
				if (m_command.isEmpty()) {
					m_command = scan.nextLine().trim();
				}
				// client exit command
				if (m_command.equalsIgnoreCase("exit")) {
					System.exit(0);
				}
				// client clear screen command
				if (m_command.equalsIgnoreCase("cls")) {
					String buf = new String(new char[80]).replace("\0", "\n");
					System.out.print(buf);
					continue;
				}
				// 2. commit command to server
				outputStream.write(m_command.getBytes());
				outputStream.flush();
				// 3. receive result from server
				byte svrBytes[] = new byte[1024];
				int bytes = inputStream.read(svrBytes);
				if (bytes > 0) {
					String response = new String(svrBytes, 0, bytes);
					System.out.println("\n" + response);
				}
			}
		} catch (Exception e) {
			// e.printStackTrace();
			// System.out.println("\nDebug: client crashed!!!!");
		}
		// System.out.print("\nClient exited.");
	}

	public static void main(String[] args) throws Throwable {
		Client_ok1 module = new Client_ok1();
		while (true) {
			module.run();
		}
	}
}