package pkgShellClient;

import java.io.OutputStream;
import java.util.Scanner;

import pkgCommon.AAI_Module;

/**
 * Client sender thread for sending client commands to server.
 * 
 * @author Allen Lin, 25 Nov 2014
 */
public class Sender extends AAI_Module {

	public Sender(OutputStream outStream) {
		setOutStream(outStream);
	}

	public void run() {
		dbgPrint(name() + " started.\n");
		@SuppressWarnings("resource")
		Scanner scan = new Scanner(System.in);
		for (String cmd;; cmd = "") {
			System.out.print("AAI> ");
			// 1. read command from user input
			if ((cmd = scan.nextLine().trim()).isEmpty()) {
				continue;
			}
			// clear client screen
			if (cmd.equalsIgnoreCase("cls")) {
				String buf = new String(new char[80]).replace("\0", "\n");
				System.out.print(buf);
				continue;
			}
			// 2. send command to server
			outStream(cmd);
			// client exit command
			if (cmd.equalsIgnoreCase("exit")) {
				break;
			}
		}
		dbgPrint("Thread " + name() + " terminated normally.\n");
	}
}