package pkgShellClient;

import java.io.InputStream;

import pkgCommon.AAI_Module;

/**
 * Client Receive thread for receiving responses and messages from server and
 * process (so far just simply print on the screen).
 * 
 * @author Allen Lin, 25 Nov 2014
 */
public class Receiver extends AAI_Module {

	public Receiver(InputStream inStream) {
		setInStream(inStream);
	}

	public void run() {
		dbgPrint(name() + " started.\n");
		byte svrBytes[] = new byte[4096];
		while (!stop()) {
			try {
				// receive message from server
				int bytes = m_inStream.read(svrBytes);
				if (bytes > 0) {
					String response = new String(svrBytes, 0, bytes);
					System.out.println(response);
					System.out.print("AAI> ");
				}
			} catch (Throwable e) {
				printException(name(), e);
				return;
			}
		}
		dbgPrint("Thread " + name() + " terminated normally.\n");
	}
}