package pkgTaskMan;

import java.io.OutputStream;
import java.util.ArrayList;

import pkgCommon.AAI_Module;

/**
 * Task Manager Module runs as a daemon thread and is used to manage tasks,
 * including: (1) create module (the task) objects, (2) set module options, (3)
 * run modules as thread tasks, (4) monitor task status, (5) etc��
 * <p>
 * <b>Syntax:</b>
 * <ul>
 * <li>CREATE task_name FROM module_jar</li>
 * <li>VIEW {task_name | ALL}</li>
 * <li>DELETE {task_name | ALL}</li>
 * <li>SET task_name OPTIONS options</li>
 * <li>RUN task_name</li>
 * <li>STOP task_name</li>
 * <li>HELP task_name</li>
 * <li>VERSION task_name</li>
 * </ul>
 * 
 * @author Allen Lin, 14 Nov 2014
 */
public class TaskMan extends AAI_Module {
	/** user keywords */
	private static final String KWD_CREATE = "CREATE";
	private static final String KWD_FROM = "FROM";
	private static final String KWD_VIEW = "VIEW";
	private static final String KWD_DELETE = "DELETE";
	private static final String KWD_SET = "SET";
	private static final String KWD_OPTIONS = "OPTIONS";
	private static final String KWD_RUN = "RUN";
	private static final String KWD_STOP = "STOP";
	private static final String KWD_HELP = "HELP";
	private static final String KWD_VERSION = "VERSION";
	private static final String KWD_ALL = "ALL";

	/** the task set [task_name, task_obj] */
	private Tasks m_tasks = new Tasks();

	/** user command set */
	private CmdFunc[] m_cmdFuncs;

	public TaskMan() {
		/** user commands supported so far */
		m_cmdFuncs = new CmdFunc[] { cmdCreate, cmdView, cmdDelete,
				cmdSetOptions, cmdRun, cmdStop, cmdHelp, cmdVersion };
	}

	/** set tasks' output streams */
	public void setOutStream(OutputStream outStream) {
		m_outStream = outStream;
		for (String taskName : m_tasks.getTaskNames()) {
			m_tasks.setOutStream(taskName, m_outStream);
		}
	}

	/** CREATE task_name FROM module_jar */
	public CmdFunc cmdCreate = new CmdFunc(KWD_CREATE, KWD_FROM) {
		public ReturnCode execute(String[] command) {
			String taskName = parseCommand(KWD_CREATE, command);
			String moduleJar = parseCommand(KWD_FROM, command);
			ReturnCode ret = m_tasks.add(taskName, moduleJar);
			m_tasks.setOutStream(taskName, m_outStream);
			return ret;
		}
	};

	/** DELETE {task_name | ALL} */
	public CmdFunc cmdDelete = new CmdFunc(KWD_DELETE) {
		public ReturnCode execute(String[] command) {
			String taskName = parseCommand(KWD_DELETE, command);
			ArrayList<String> taskNames = new ArrayList<String>();
			if (taskName.equalsIgnoreCase(KWD_ALL)) {
				taskNames.addAll(m_tasks.taskNames());
			} else {
				taskNames.add(taskName);
			}
			String msg = new String();
			for (int i = 0; i < taskNames.size(); i++) {
				ReturnCode ret = m_tasks.delete(taskNames.get(i));
				msg += (ret == ReturnCode.SUCCESS) ? "" : ((msg.isEmpty() ? ""
						: "\n") + ret);
			}
			retMsg(msg);
			return (msg.isEmpty() ? ReturnCode.SUCCESS : ReturnCode.FAIL);
		}
	};
	/** VIEW {task_name | ALL} */
	public CmdFunc cmdView = new CmdFunc(KWD_VIEW) {
		public ReturnCode execute(String[] command) {
			String taskName = parseCommand(KWD_VIEW, command);
			ArrayList<String> taskNames = new ArrayList<String>();
			if (taskName.equalsIgnoreCase(KWD_ALL)) {
				taskNames.addAll(m_tasks.taskNames());
			} else {
				taskNames.add(taskName);
			}
			String msg = new String();
			for (int i = 0; i < taskNames.size(); i++) {
				ReturnCode ret = m_tasks.view(taskNames.get(i));
				msg += ((i == 0) ? "" : "\n") + ret;
			}
			retMsg(msg);
			return ReturnCode.SUCCESS;
		}
	};

	/** SET task_name OPTIONS options */
	public CmdFunc cmdSetOptions = new CmdFunc(KWD_SET, KWD_OPTIONS) {
		public ReturnCode execute(String[] command) {
			String taskName = parseCommand(KWD_SET, command);
			String options = parseCommand(KWD_OPTIONS, command);
			return m_tasks.setOptions(taskName, options);
		}
	};

	/** RUN task_name */
	public CmdFunc cmdRun = new CmdFunc(KWD_RUN) {
		public ReturnCode execute(String[] command) {
			String taskName = parseCommand(KWD_RUN, command);
			return m_tasks.run(taskName);
		}
	};

	/** STOP task_name */
	public CmdFunc cmdStop = new CmdFunc(KWD_STOP) {
		public ReturnCode execute(String[] command) {
			String taskName = parseCommand(KWD_STOP, command);
			return m_tasks.stop(taskName);
		}
	};

	/** HELP task_name */
	public CmdFunc cmdHelp = new CmdFunc(KWD_HELP) {
		public ReturnCode execute(String[] command) {
			String taskName = parseCommand(KWD_HELP, command);
			return m_tasks.help(taskName);
		}
	};

	/** VERSION task_name */
	public CmdFunc cmdVersion = new CmdFunc(KWD_VERSION) {
		public ReturnCode execute(String[] command) {
			String taskName = parseCommand(KWD_VERSION, command);
			return m_tasks.version(taskName);
		}
	};

	/**
	 * return : [return_code return_message].<br>
	 * e.g., "0 Error: failed to load module jar."<br>
	 * return_code = 0 (success), 1 (warning), or -1 (error)
	 */
	public String execCmd(String command) {
		String[] cmds = command.trim().replaceAll(" +", " ").split(" ");
		for (CmdFunc cmdFunc : m_cmdFuncs) {
			if (cmdFunc.support(cmds)) {
				ReturnCode retCode = cmdFunc.execute(cmds);
				return CmdFunc.retCodeMsg(retCode, retMsg());
			}
		}
		return CmdFunc.retCodeMsg(ReturnCode.WARNING, "unrecognized command!");
	}

	public static String version() {
		return "V0.0.0.1, Created on 19 Nov 2014, Allen Lin.\n";
	}
}