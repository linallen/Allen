package pkgTaskMan;

import pkgCommon.AAI_Module;

/**
 * All information about a task.
 * 
 * @author Allen Lin, 20 Nov 2014
 */
public class Task extends AAI_Module {
	/** main module */
	private AAI_Module m_module;

	/** the .jar file from which module was loaded */
	private String m_moduleJar;

	public AAI_Module module() {
		return m_module;
	}

	public Task(String name, AAI_Module module, String moduleJar) {
		name(name.intern());
		m_module = module;
		m_moduleJar = moduleJar;
	}

	public String toString() {
		return name() + ", " + m_module.name() + ", " + m_moduleJar + ", "
				+ m_module.statusStr();
	}
}