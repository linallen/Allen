package pkgTaskMan;

import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;

import pkgCommon.AAI_Module;
import pkgCommon.Common;

/**
 * task collection.
 * 
 * @author Allen Lin, 21 Nov 2014
 */

public class Tasks extends AAI_Module {
	/** return code from executing a command. */
	private static final String SUCCESS = "\n[SUCCESS]\n\n";
	private static final String WARNING = "\n[WARNING]\n\n";
	private static final String ERROR = "\n[ERROR]\n\n";

	private static final String errKwdAll = "\" ALL\" is a keyword.";

	private static final String errExist(String taskName, boolean exist) {
		return ERROR + "task " + Common.quote(taskName)
				+ (exist ? " already" : " not") + " exist.";
	}

	private static final String errRunning(String taskName) {
		return ERROR + "task " + Common.quote(taskName) + " is running.";
	}

	private static final String errLoadJar(String taskName, String moduleJar) {
		return ERROR + "failed to create task " + Common.quote(taskName)
				+ " from " + Common.quote(moduleJar) + ".";
	}

	private static final String errSetOptions(String taskName, String options) {
		return ERROR + "failed to set task " + Common.quote(taskName)
				+ "'s options " + Common.quote(options);
	}

	/** the task set [task_name, task_obj] */
	private HashMap<String, Task> m_tasks = new HashMap<String, Task>();

	/** check if task exists or not */
	private boolean taskExist(String taskName) {
		return m_tasks.get(taskName) != null;
	}

	/** check if task is running */
	private boolean taskRunning(String taskName) {
		Task task = m_tasks.get(taskName);
		return task.module().status() == Status.RUNNING;
	}

	/** set task's output stream: System.out or clientSocket.OutputStream */
	public void setOutStream(String taskName, OutputStream outStream) {
		m_tasks.get(taskName).module().setOutStream(outStream);
	}

	/** return tasks's name set */
	public Set<String> getTaskNames() {
		return m_tasks.keySet();
	}

	/** CREATE task FROM module_jar */
	public ReturnCode add(String taskName, String moduleJar) {
		if (taskName.equalsIgnoreCase("ALL")) {
			retMsg(errKwdAll);
			return ReturnCode.FAIL;
		}
		if (taskExist(taskName)) {
			retMsg(errExist(taskName, true));
			return ReturnCode.FAIL;
		}
		// 1. load module_jar and instantiate it
		AAI_Module module = AAI_Module.loadJar(moduleJar);
		if (module == null) {
			retMsg(errLoadJar(taskName, moduleJar));
			return ReturnCode.FAIL;
		}
		// 2. add new task to task set
		m_tasks.put(taskName, new Task(taskName, module, moduleJar));
		retMsg("task created successfully.");
		return ReturnCode.SUCCESS;
	}

	/** DELETE task */
	public ReturnCode delete(String taskName) {
		if (!taskExist(taskName)) {
			retMsg(errExist(taskName, false));
			return ReturnCode.FAIL;
		}
		if (taskRunning(taskName)) {
			retMsg(errRunning(taskName));
			return ReturnCode.FAIL;
		}
		m_tasks.remove(taskName);
		retMsg("task deleted successfully.");
		return ReturnCode.SUCCESS;
	}

	/** SET task OPTIONS */
	public ReturnCode setOptions(String taskName, String options) {
		if (!taskExist(taskName)) {
			retMsg(errExist(taskName, false));
			return ReturnCode.FAIL;
		}
		if (taskRunning(taskName)) {
			retMsg(errRunning(taskName));
			return ReturnCode.FAIL;
		}
		try {
			m_tasks.get(taskName).module().setOptions(options.split("~"));
		} catch (Throwable e) {
			retMsg(errSetOptions(taskName, options));
			return ReturnCode.FAIL;
		}
		retMsg("task options set  successfully.");
		return ReturnCode.SUCCESS;
	}

	/** RUN task */
	public ReturnCode run(String taskName) {
		if (!taskExist(taskName)) {
			retMsg(errExist(taskName, false));
			return ReturnCode.FAIL;
		}
		if (taskRunning(taskName)) {
			retMsg(errRunning(taskName));
			return ReturnCode.FAIL;
		}
		Task task = m_tasks.get(taskName);
		AAI_Module module = task.module();
		module.status(Status.RUNNING);
		module.start();
		retMsg("task started successfully.");
		return ReturnCode.SUCCESS;
	}

	/** STOP task */
	public ReturnCode stop(String taskName) {
		if (!taskExist(taskName)) {
			retMsg(errExist(taskName, false));
			return ReturnCode.FAIL;
		}
		Task task = m_tasks.get(taskName);
		AAI_Module module = task.module();
		if (module.status() != Status.RUNNING) {
			retMsg(WARNING + "task is not running.");
			return ReturnCode.FAIL;
		}
		module.status(Status.STOPPED);
		retMsg("task stopped successfully.");
		return ReturnCode.SUCCESS;
	}

	/** HELP task */
	public ReturnCode help(String taskName) {
		if (!taskExist(taskName)) {
			retMsg(errExist(taskName, false));
			return ReturnCode.FAIL;
		}
		Task task = m_tasks.get(taskName);
		retMsg(task.module().help());
		return ReturnCode.SUCCESS;
	}

	/** VERSION task */
	public ReturnCode version(String taskName) {
		if (!taskExist(taskName)) {
			retMsg(errExist(taskName, false));
			return ReturnCode.FAIL;
		}
		Task task = m_tasks.get(taskName);
		retMsg(task.module().version());
		return ReturnCode.SUCCESS;
	}

	/** return task names[] */
	public ArrayList<String> taskNames() {
		ArrayList<String> taskNames = new ArrayList<String>(m_tasks.keySet());
		return taskNames;
	}

	/** VIEW task */
	public ReturnCode view(String taskName) {
		if (!taskExist(taskName)) {
			retMsg(errExist(taskName, false));
			return ReturnCode.FAIL;
		}
		Task task = m_tasks.get(taskName);
		retMsg(task.toString());
		return ReturnCode.SUCCESS;
	}
}