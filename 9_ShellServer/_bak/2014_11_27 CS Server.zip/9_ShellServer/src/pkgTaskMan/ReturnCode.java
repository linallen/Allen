package pkgTaskMan;

/** return code from executing a command. */
public enum ReturnCode {
	SUCCESS("SUCCESS"), WARNING("WARNING"), FAIL("FAIL");

	ReturnCode(String retCode) {
		m_retCode = retCode.intern();
	}

	private String m_retCode;

	public String toString() {
		return m_retCode;
	}
}
