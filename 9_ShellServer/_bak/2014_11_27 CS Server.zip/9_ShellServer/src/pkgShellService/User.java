package pkgShellService;

import pkgCommon.AAI_Module;
import pkgTaskMan.TaskMan;

/**
 * Each User object servers one user with one task manager.
 * 
 * @author Allen Lin, 26 Nov 2014
 */
public class User extends AAI_Module {
	/** anonymous user number */
	private static int m_visitorNum;

	/** user type: admin or common */
	private UserType m_userType = UserType.USER;

	/** task manager managed by this user */
	private TaskMan m_taskMan = new TaskMan();

	/** user type: admin, user or anonymous */
	public enum UserType {
		ADMIN("Admin"), USER("User"), VISITOR("Visitor");
		private String m_type;

		UserType(String type) {
			m_type = type;
		}

		public String toString() {
			return m_type;
		}
	}

	public User(UserType userType) {
		m_userType = userType;
		if (userType == UserType.ADMIN) {
			name("admin");
		}
		if (userType == UserType.VISITOR) {
			name("visitor_" + (++m_visitorNum));
		}
	}

	/** new a common user */
	public User(String userName) {
		name(userName);
	}

	/** decrease visitor number by 1 */
	public void logoutVisitors() {
		m_visitorNum--;
	}

	/** 1. set task manager */
	public void taskMan(TaskMan taskMan) {
		m_taskMan = taskMan;
	}

	/** 1. get task manager */
	public TaskMan taskMan() {
		return m_taskMan;
	}

	/** 2. get user type */
	public UserType type() {
		return m_userType;
	}

	public String toString() {
		return name() + ", " + type().toString();
	}
}