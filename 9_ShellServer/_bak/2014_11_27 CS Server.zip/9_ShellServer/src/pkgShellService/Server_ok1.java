package pkgShellService;

import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;

import pkgTaskMan.TaskMan;

public class Server_ok1 {
	/** server socket. */
	private static ServerSocket m_svrSocket;
	/** server port. TODO: be configured by starting parameters */
	private static int m_port = 9999;
	/** server IP */
	private static String m_ip;

	/** task manager */
	private static TaskMan m_taskMan;

	/** start service */
	public static void start(String args[]) {
		try {
			m_taskMan = new TaskMan();
			m_ip = InetAddress.getLocalHost().getHostAddress();
			m_svrSocket = new ServerSocket(m_port);
			System.out.println("Started service on " + m_ip + ":" + m_port);
		} catch (Exception ex) {
			System.out.println("Can't start service on " + m_ip + ":" + m_port);
			ex.printStackTrace();
		}
		byte cltRequest[] = new byte[1024];
		while ((m_svrSocket != null) && !m_svrSocket.isClosed()) {
			try {
				System.out.println("\nListening on " + m_ip + ":" + m_port);
				Socket cltSocket = m_svrSocket.accept();
				System.out.println("Client from " + cltSocket.getInetAddress()
						+ ":" + cltSocket.getPort() + " connected at "
						+ (new java.util.Date().toString()));
				int n = cltSocket.getInputStream().read(cltRequest);
				String request = new String(cltRequest, 0, n);
				System.out.println("Client request: " + request + "\n");
				String res = m_taskMan.excuteCommand(request);
				cltSocket.getOutputStream().write(" SERVER BEGIN: ".getBytes());
				cltSocket.getOutputStream().write(res.getBytes());
				cltSocket.getOutputStream().write(" SERVER END! ".getBytes());
				cltSocket.getOutputStream().flush();
				cltSocket.close();
			} catch (Exception ex) {
				// ex.printStackTrace();
			}
		}
	}

	public static synchronized void stop(String arg[]) {
		try {
			if (m_svrSocket != null) {
				m_svrSocket.close();
				m_svrSocket = null;
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		System.out.println("Stopped service successfully.");
	}

	public static void main(String[] args) {
		Server_ok1.start("".split(" "));
	}
}