package pkgShellService;

import java.io.IOException;
import java.net.Socket;

import pkgCommon.AAI_Module;
import pkgShellService.User.UserType;
import pkgTaskMan.CmdFunc;
import pkgTaskMan.ReturnCode;
import pkgTaskMan.TaskMan;

/**
 * One service thread, created by the Server, provides service for one user at a
 * time via client socket.
 * 
 * @author Allen Lin, 26 Nov 2014
 */
public class Service extends AAI_Module {
	/** the client socket via which to communicate with client */
	private Socket m_cltSocket;

	/** the user using this service thread */
	private User m_user = new User(UserType.VISITOR);

	/** system keywords */
	private static final String KWD_NEWUSER = "NEWUSER";
	private static final String KWD_VIEWUSER = "VIEWUSER";
	private static final String KWD_SWITCHUSER = "SWITCHUSER";
	private static final String KWD_DELUSER = "DELUSER";
	private static final String KWD_LOAD = "LOAD";
	private static final String KWD_FROM = "FROM";
	private static final String KWD_SYSTEM = "SYSTEM";
	private static final String KWD_ALL = "ALL";

	/** system command set */
	private CmdFunc[] m_cmdSysFuncs;

	public String userName() {
		return m_user.name();
	}

	/** create a new "service" thread */
	public Service(Socket cltSocket) throws Throwable {
		m_cltSocket = cltSocket;
		setInStream(cltSocket.getInputStream());
		setOutStream(cltSocket.getOutputStream());
		TaskMan taskMan = m_user.taskMan();
		taskMan.setOutStream(m_outStream);
		/** user commands supported so far */
		m_cmdSysFuncs = new CmdFunc[] { cmdNewUser, cmdViewUser, cmdSwitchUser,
				cmdDelUser };
	}

	/** (system) NEWUSER user_name */
	public CmdFunc cmdNewUser = new CmdFunc(KWD_NEWUSER) {
		public ReturnCode execute(String[] command) {
			String userName = parseCommand(KWD_NEWUSER, command);
			if (userName.isEmpty()) {
				retMsg("please give a user name.");
				return ReturnCode.FAIL;
			}
			if (Server.getUser(userName) != null) {
				retMsg("user " + userName + " has already been created.");
				return ReturnCode.FAIL;
			}
			if (userName.equalsIgnoreCase(KWD_ALL)) {
				retMsg("user name can not be keyword " + KWD_ALL + ".");
				return ReturnCode.FAIL;
			}
			boolean success = Server.addUser(userName);
			if (success) {
				retMsg("user " + userName + " created successfully.");
				return ReturnCode.SUCCESS;
			} else {
				retMsg("user " + userName + " created unsuccessfully.");
				return ReturnCode.FAIL;
			}
		}
	};

	/** (system) VIEWUSER user_name | ALL */
	public CmdFunc cmdViewUser = new CmdFunc(KWD_VIEWUSER) {
		public ReturnCode execute(String[] command) {
			String userName = parseCommand(KWD_VIEWUSER, command);
			if (userName.isEmpty()) {
				retMsg("current user is " + userName());
				return ReturnCode.SUCCESS;
			}
			if (userName.equalsIgnoreCase(KWD_ALL)) {
				String retMsg = new String();
				for (User user : Server.getUsers()) {
					retMsg += user.toString() + "\n";
				}
				retMsg(retMsg);
				return ReturnCode.SUCCESS;
			}
			User user = Server.getUser(userName);
			if (user == null) {
				retMsg("user " + userName + " does not exist.");
				return ReturnCode.FAIL;
			}
			retMsg(user.toString());
			return ReturnCode.SUCCESS;
		}
	};

	/** (system) SWITCHUSER user_name */
	public CmdFunc cmdSwitchUser = new CmdFunc(KWD_SWITCHUSER) {
		public ReturnCode execute(String[] command) {
			String userName = parseCommand(KWD_SWITCHUSER, command);
			if (userName.isEmpty()) {
				retMsg("please give a user name.");
				return ReturnCode.FAIL;
			}
			User user = Server.getUser(userName);
			if (user == null) {
				retMsg("user " + userName + " does not exist.");
				return ReturnCode.FAIL;
			}
			m_user = user;
			retMsg("switched to user " + m_user.name());
			return ReturnCode.SUCCESS;
		}
	};

	/** (system) DELUSER user_name | ALL */
	public CmdFunc cmdDelUser = new CmdFunc(KWD_DELUSER) {
		public ReturnCode execute(String[] command) {
			if (m_user.type() != UserType.ADMIN) {
				retMsg("only Admin user can delete user(s).");
				return ReturnCode.FAIL;
			}
			String userName = parseCommand(KWD_DELUSER, command);
			if (userName.isEmpty()) {
				retMsg("please give a user name.");
				return ReturnCode.FAIL;
			}
			if (userName.equalsIgnoreCase(KWD_ALL)) {
				String retMsg = new String();
				boolean ret = false;
				for (User user : Server.getUsers()) {
					if (user.type() != UserType.ADMIN) {
						String name = user.name();
						ret = ret && Server.delUser(user.name());
						retMsg += "user " + name
								+ (ret ? " has been " : " failed to be ")
								+ "deleted.\n";
					}
				}
				retMsg(retMsg);
				return ret ? ReturnCode.SUCCESS : ReturnCode.WARNING;
			}
			User user = Server.getUser(userName);
			if (user == null) {
				retMsg("user " + userName + " does not exist.");
				return ReturnCode.FAIL;
			}
			if (user.type() == UserType.ADMIN) {
				retMsg("user " + userName + " can not be deleted.");
				return ReturnCode.FAIL;
			}
			Server.delUser(userName);
			retMsg(userName + " has been deleted.");
			return ReturnCode.SUCCESS;
		}
	};

	/** (system) LOAD module_name FROM module_jar */
	public CmdFunc cmdLoadFrom = new CmdFunc(KWD_LOAD, KWD_FROM) {
		public ReturnCode execute(String[] command) {
			String moduleName = parseCommand(KWD_LOAD, command);
			String moduleJar = parseCommand(KWD_FROM, command);
			return ReturnCode.SUCCESS;
		}
	};

	public void run() {
		byte clientBytes[] = new byte[4096];
		String command;
		int n;
		try {
			while (status() != Status.STOPPED) {
				n = m_inStream.read(clientBytes);
				command = new String(clientBytes, 0, n);
				System.out.println(name() + ": client request <" + command
						+ ">\n");
				if (command.equalsIgnoreCase("exit")) {
					System.out.println("Disconnected by client.\n");
					return;
				}
				// 1. execute system command
				String retCodeMsg = new String();
				String[] cmds = command.trim().replaceAll(" +", " ").split(" ");
				for (CmdFunc cmdFunc : m_cmdSysFuncs) {
					if (cmdFunc.support(cmds)) {
						ReturnCode retCode = cmdFunc.execute(cmds);
						retCodeMsg = CmdFunc.retCodeMsg(retCode, retMsg());
						break;
					}
				}
				if (retCodeMsg.isEmpty()) {
					// 2. execute user command
					TaskMan taskMan = m_user.taskMan();
					retCodeMsg = taskMan.execCmd(command);
				}
				outStream(retCodeMsg);
			}
		} catch (Exception e) {
			printException(name(), e);
			e.printStackTrace();
			return;
		} finally {
			try {
				m_cltSocket.close();
				System.out.println(name() + ": socket closed successfully.");
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}