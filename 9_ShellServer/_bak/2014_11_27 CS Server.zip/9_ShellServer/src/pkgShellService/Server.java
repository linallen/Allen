package pkgShellService;

import java.net.ServerSocket;
import java.net.Socket;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;

import pkgCommon.AAI_Module;
import pkgShellService.User.UserType;

/**
 * Server.
 * 
 * @author Allen Lin, 25 Nov 2014
 */
public class Server extends AAI_Module {
	private static HashSet<Service> m_services = new HashSet<Service>();
	private static HashMap<String, User> m_users = new HashMap<String, User>();

	/** return a User object by user name */
	public static synchronized User getUser(String userName) {
		return m_users.get(userName);
	}

	public static synchronized boolean addUser(String userName) {
		return m_users.put(userName, new User(userName)) == null;
	}

	public static synchronized boolean delUser(String userName) {
		return m_users.remove(userName) != null;
	}

	public static Collection<User> getUsers() {
		return m_users.values();
	}

	/** start service */
	@SuppressWarnings("resource")
	public static void start(String args[]) {
		// create "admin" user
		User userAdmin = new User(UserType.ADMIN);
		m_users.put(userAdmin.name(), userAdmin);

		ServerSocket svrSocket = null;
		// 1. bind service with port and listen
		try {
			int port = (args.length) > 0 ? Integer.parseInt(args[0]) : 9999;
			System.out.println("\nListening on :" + port);
			svrSocket = new ServerSocket(port);
		} catch (Throwable e) {
			printException("Server", e);
			return;
		}
		// 2. listen connections and create "service" thread to response clients
		while (true) {
			try {
				Socket cltSocket = svrSocket.accept();
				System.out.println("Client from " + cltSocket.getInetAddress()
						+ ":" + cltSocket.getPort() + " connected at "
						+ (new java.util.Date().toString()));
				Service service = new Service(cltSocket);
				m_services.add(service);
				service.start();
				System.out.println("started a service thread " + service.name()
						+ " for user " + service.userName());
			} catch (Throwable e) {
				printException("Server", e);
				e.printStackTrace();
				return;
			}
		}
	}

	/** stop service */
	public static void stop(String arg[]) {
		System.out.println("Stopped service successfully.");
	}

	public static void main(String[] args) {
		Server.start(args);
	}

	@Override
	public void run() {
	}
}