package pkgShellService;

import java.io.OutputStream;
import java.net.BindException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;

import pkgTaskMan.TaskMan;

public class Server_ok2 {
	/** start service */
	public static void start(String args[]) {
		// task manager
		TaskMan m_taskMan = new TaskMan();
		while (true) {
			try {
				// int port = Integer.parseInt(args[0]);
				int port = 9999;
				System.out.println("\nListening on "
						+ InetAddress.getLocalHost().getHostAddress() + ":"
						+ port);
				// 1. bind service with port and listen
				@SuppressWarnings("resource")
				ServerSocket svrSocket = new ServerSocket(port);
				Socket cltSocket = svrSocket.accept();
				System.out.println("Client from " + cltSocket.getInetAddress()
						+ ":" + cltSocket.getPort() + " connected at "
						+ (new java.util.Date().toString()));
				// 2 enable all task modules to push messages to client.
				OutputStream out = cltSocket.getOutputStream();
				m_taskMan.setOutStream(out);
				while ((svrSocket != null) && !svrSocket.isClosed()) {
					byte cltRequest[] = new byte[1024];
					int n = cltSocket.getInputStream().read(cltRequest);
					String request = new String(cltRequest, 0, n);
					System.out.println("Client request: <" + request + ">\n");
					if (request.equalsIgnoreCase("exit")) {
						// disconnection from client
						System.out.println("Disconnected by client.\n");
						break;
					}
					String res = m_taskMan.excuteCommand(request);
					// out.write(" SERVER BEGIN: ".getBytes());
					out.write(res.getBytes());
					// out.write(" SERVER END! ".getBytes());
					// debug
					for (int i = 0; i < 0; i++) {
						String response = "response " + i + "\n";
						out.write(response.getBytes());
					}
					// debug
					out.flush();
				}
				cltSocket.close();
			} catch (BindException ex) {
				System.out.println("BindException: " + ex.getMessage());
				ex.printStackTrace();
				break;
			} catch (Exception ex) {
				System.out.println("\n\nServer stopped unexpectly.");
				ex.printStackTrace();
				break;
			} finally {
				// TODO: save m_taskMan to file for restore.
				System.out.println("\n\nTODO: Save m_taskMan into file.");
			}
		}
	}

	/** stop service */
	public static void stop(String arg[]) {
		System.out.println("Stopped service successfully.");
	}

	public static void main(String[] args) {
		Server_ok2.start(args);
	}
}