package pkgTaskMan;

import java.net.URL;
import java.util.HashMap;

import pkgCommon.AAI_Module;
import pkgCommon.Common;
import pkgJarLoader.JarLoader;

/**
 * Task Manager Module runs as a daemon thread and is used to manage tasks,
 * including: (1) create module (the task) objects, (2) set module options, (3)
 * run modules as thread tasks, (4) monitor task status, (5) etc��
 * <p>
 * <b>Syntax & Examples</b><br>
 * CREATE task_name FROM module_jar<br>
 * CREATE df_task1 FROM c:/df.jar
 * <p>
 * VIEW {task_name | all}<br>
 * VIEW df_task1<br>
 * VIEW all<br>
 * 
 * @author Allen Lin, 14 Nov 2014
 */
public class TaskMan {
	/** keywords */
	private static final String KWD_CREATE = "CREATE";
	private static final String KWD_FROM = "FROM";
	private static final String KWD_VIEW = "VIEW";
	private static final String KWD_SET = "SET";
	private static final String KWD_OPTIONS = "OPTIONS";
	private static final String KWD_RUN = "RUN";
	private static final String KWD_PAUSE = "PAUSE";
	private static final String KWD_STOP = "STOP";
	private static final String KWD_ALL = "ALL";

	private static final String ERR_UNRECOGNIZED_COMMAND = "Error: unrecognized command";

	/** the task set [task_name, task_obj] */
	private HashMap<String, AAI_Module> m_tasks = new HashMap<String, AAI_Module>();

	/** results to be send back to client */
	private String m_result = new String();

	//
	// public static boolean isEmpty(String[] strings) {
	// try {
	// for (String string : strings) {
	// if (!string.isEmpty()) {
	// return false;
	// }
	// }
	// } catch (Exception e) {
	// e.printStackTrace();
	// }
	// return true;
	// }

	/**
	 * return the parameter of a given keyword from command[] and remove them.<br>
	 * return null if the keyword does not exist.
	 */
	private static String parseCommand(String keyword, String[] commands) {
		for (int i = 0; i < commands.length; i++) {
			if (keyword.equalsIgnoreCase(commands[i])) {
				commands[i] = "";
				if (i < commands.length - 1) {
					String parameter = commands[i + 1];
					commands[i + 1] = "";
					return parameter;
				}
				return "";
			}
		}
		return null;
	}

	/**
	 * check if commands[] contains all keywords[].<br>
	 * Note: keyword must be in even position, i.e., 0, 2, 4, ...
	 */
	private static boolean containKwds(String[] commands, String... keywords) {
		for (int i = 0; i < commands.length; i += 2) {
			boolean contain = false;
			for (int j = 0; j < keywords.length; j++) {
				if (keywords[j].equalsIgnoreCase(commands[i])) {
					contain = true;
					break;
				}
			}
			if (contain == false) {
				return false;
			}
		}
		return true;
	}

	/** CREATE task_name FROM module_jar */
	private boolean cmdCreate(String[] commands) {
		// task name should be unique in the task set.
		String taskName = parseCommand(KWD_CREATE, commands);
		// URL of the module's .jar file.
		String moduleJar = parseCommand(KWD_FROM, commands);

		System.out.println("taskName = " + taskName);
		System.out.println("moduleJar = " + moduleJar);

		if (!Common.isEmpty(commands)) {
			m_result = ERR_UNRECOGNIZED_COMMAND;
			return false;
		}
		if ((taskName == null) || taskName.isEmpty()) {
			m_result = ERR_UNRECOGNIZED_COMMAND + " taskName";
			return false;
		}
		if (taskName.equalsIgnoreCase("all")) {
			m_result = "Error: \"all\" is a keyword, use other name.";
			return false;
		}
		if ((moduleJar == null) || moduleJar.isEmpty()) {
			m_result = ERR_UNRECOGNIZED_COMMAND + " moduleJar";
			return false;
		}
		if (!Common.fileExist(moduleJar)) {
			m_result = "moduleJar \"" + moduleJar + "\" does not exist.";
			return false;
		}
		if (m_tasks.get(taskName) != null) {
			m_result = "Error: task " + taskName + " alread exist.";
			return false;
		}
		// 1. load module_jar and instantiate it
		AAI_Module module = AAI_Module.loadJar(moduleJar);
		if (module == null) {
			m_result = "Error: load " + moduleJar + " failed.";
			return false;
		}
		// 2. add new task to task set
		m_tasks.put(taskName, module);
		return true;
	}

	// debug
	@SuppressWarnings("resource")
	public static AAI_Module loadJar(String jarFile) {
		try {
			URL jarURL = new URL("file:" + jarFile);
			System.out.println("1 " + jarFile);
			JarLoader jarLoader = new JarLoader(jarURL);
			System.out.println("2 " + jarURL.toString());
			String mainClassName = jarLoader.getMainClassName();
			System.out.println("3 " + mainClassName);
			Class<?> mainClass = jarLoader.loadClass(mainClassName);
			System.out.println("4 " + mainClass.getSimpleName());
			if (AAI_Module.class.isAssignableFrom(mainClass)) {
				System.out.println("5");
				return (AAI_Module) mainClass.newInstance();
			}
		} catch (Throwable e) {
			e.printStackTrace();
		}
		System.out.println("6");
		return null;
	}

	// debug

	/** VIEW {task_name | all} */
	private boolean cmdView(String[] commands) {
		String taskName = parseCommand(KWD_VIEW, commands);
		// debug
		System.out.println("command[] len = : " + commands.length);
		for (int i = 0; i < commands.length; i++) {
			System.out.println("command[" + i + "] = \"" + commands[i] + "\"");
		}
		// debug
		if (!Common.isEmpty(commands)) {
			m_result = ERR_UNRECOGNIZED_COMMAND;
			return false;
		}
		Object[] taskNames = new Object[] { taskName };
		if (taskName.isEmpty() || taskName.equalsIgnoreCase(KWD_ALL)) {
			taskNames = m_tasks.keySet().toArray();
		}
		for (Object nameObj : taskNames) {
			String name = (String) nameObj;
			AAI_Module module = m_tasks.get(nameObj);
			System.out.println("name = " + name);
			System.out.println("module.name() = " + module.name());
			m_result += name + ", " + module.name() + "\n";
		}
		return true;
	}

	public String excuteCommand(String command) {
		m_result = new String(); // clear result buffer
		String[] commands = command.trim().split(" ");
		boolean success = false;
		System.out.println("TaskMan: started excuting " + command);
		if (containKwds(commands, KWD_CREATE, KWD_FROM)) {
			// CREATE task_name FROM module_jar
			System.out.println("cmdCreate() start!");
			success = cmdCreate(commands);
			System.out.println("cmdCreate() end!");
		} else if (containKwds(commands, KWD_VIEW)) {
			// VIEW {task_name | all}
			System.out.println("cmdView() start!");
			success = cmdView(commands);
			System.out.println("cmdView() end!");
		} else {
			m_result = "Unrecogonised command.";
		}
		System.out.println("TaskMan: finished excuting \"" + command + "\"");
		return success ? "success" : "failed" + " - " + m_result;
	}

	public static String version() {
		return "V0.0.0.1, Created on 19 Nov 2014, Allen Lin.\n";
	}
}