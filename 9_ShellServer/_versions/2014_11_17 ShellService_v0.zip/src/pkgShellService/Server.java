package pkgShellService;

import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
	private static ServerSocket serverSocket = null;
	private static boolean running = true;
	private static int m_port = 12345;

	public static void main(String args[]) {
		String mode = args[0];
		if (mode.equalsIgnoreCase("start")) {
			start(args);
		}
	}

	public static void start(String args[]) {
		Socket client = null;
		try {
			System.out.println("Starting service on IP Address "
					+ InetAddress.getLocalHost().getHostAddress() + " port "
					+ m_port);
			for (int i = 0; i < args.length; i++) {
				System.out.println("arg [" + i + "] = " + args[i]);
			}
			serverSocket = new ServerSocket(m_port);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		byte b[] = new byte[256];
		String tmp = null;
		while (running && (serverSocket != null) && !serverSocket.isClosed()) {
			try {
				System.out.println("Listening for clients on IP Address "
						+ InetAddress.getLocalHost().getHostAddress()
						+ " port " + m_port);
				client = serverSocket.accept();
				System.out.println("Client from " + client.getInetAddress()
						+ ":" + client.getPort() + " connected at "
						+ (new java.util.Date().toString()));
				int n = client.getInputStream().read(b);
				tmp = new String(b, 0, n).replaceAll(",", "");
				double x = Double.parseDouble(tmp);
				double y = x * x;
				client.getOutputStream().write(("" + y).getBytes());
				client.getOutputStream().flush();
				System.out.println("Received " + x + " and sent " + y);
				client.close();
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
		System.out.println("start() finished!");
	}

	public static void stop(String arg[]) {
		System.out.println("Bye !!!");
		if (running) {
			running = false;
			try {
				if (serverSocket != null) {
					serverSocket.close();
					serverSocket = null;
				}
			} catch (Exception ex) {
				ex.printStackTrace();
			}
			System.out.println("Stopped service!!!");
		}
	}
}