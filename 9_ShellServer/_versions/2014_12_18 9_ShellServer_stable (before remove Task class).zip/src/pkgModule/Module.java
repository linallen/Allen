package pkgModule;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.reflect.Method;

import pkgCommon.AAI_Module;
import pkgCommon.Common;

/**
 * General module class which<br>
 * 1. can be loaded from file (loadModule()), both local and remote.<br>
 * 2. can make a new copy (copy()).<br>
 * 3. a Module can be: AAI_Module, the main class loaded from a .jar file, or
 * any external file.
 * 
 * @author Allen Lin, 3 Dec 2014
 */
public class Module extends AAI_Module {
	private static final long serialVersionUID = -7360027778759477361L;

	/** module file */
	private String m_moduleFile;

	/**
	 * main class name.<br>
	 * "" means moduleFile is a jar file but has no main class,<br>
	 * null means moduleFile is not a jar file.
	 */
	private String m_mainClassName;

	/** main class (the actual module) */
	private transient Class<?> m_mainClass;

	/** an instance of main class */
	private transient Object m_module;

	/** main() method of the main class */
	private transient Method m_mainMethod;

	/** process of non-thread-able modules */
	private transient Process m_process;

	/** load module from file */
	public void loadModule(String moduleName, String moduleFile)
			throws Exception {
		name(moduleName);
		m_moduleFile = moduleFile;
		m_mainClassName = ModuleLoader.getMainClassName(moduleFile);
		m_mainClass = ModuleLoader.getMainClass(moduleFile);
		m_module = m_mainClass.newInstance();
		m_mainMethod = ModuleLoader.getMainMethod(m_mainClass);
	}

	/** TODO: DELETE module copy */
	public Module copy() throws Exception {
		Module moduleCopy = (Module) Common.deepCopy(this);
		moduleCopy.m_mainClass = m_mainClass;
		moduleCopy.m_module = ((m_mainClass != null) ? m_mainClass
				.newInstance() : null);
		moduleCopy.m_mainMethod = m_mainMethod;
		return moduleCopy;
	}

	/** module copy */
	public Module newInstance(String name, AAI_Module owner) throws Exception {
		Module newModule = (Module) Common.deepCopy(this);
		newModule.name(name);
		newModule.owner(owner);
		newModule.updateDirs(owner.workDir() + name);
		newModule.m_mainClass = m_mainClass;
		newModule.m_module = ((m_mainClass != null) ? m_mainClass.newInstance()
				: null);
		if (isAAI_Module(m_module)) {
			((AAI_Module) m_module).name(this.name());
			((AAI_Module) m_module).owner(this);
			((AAI_Module) m_module).updateDirs(this.workDir());
		}
		newModule.m_mainMethod = m_mainMethod;
		return newModule;
	}

	/** get main class */
	public Class<?> mainClass() {
		return m_mainClass;
	}

	/** get module object */
	public Object module() {
		return m_module;
	}

	/** get module progress [0% ~ 100%] */
	@Override
	public int progress() {
		if (isAAI_Module(m_module)) {
			return ((AAI_Module) m_module).progress();
		}
		return -1;
	}

	/** 1. get task name */
	@Override
	public String fullName() {
		if (isAAI_Module(m_module)) {
			return name() + " (" + ((AAI_Module) m_module).name() + ")";
		}
		return name();
	}

	@Override
	public boolean isRunning() {
		if (isAAI_Module(m_module)) {
			return ((AAI_Module) m_module).isRunning();
		}
		return status() == Status.RUNNING;
	}

	/** pass options to the module. */
	@Override
	public void setOptions(String[] options) throws Exception {
		try {
			m_options = Common.getString(options);
			if (isAAI_Module(m_module)) {
				((AAI_Module) m_module).setOptions(options);
				((AAI_Module) m_module).options(Common.getString(options));
			}
		} catch (Exception e) {
			m_options = "";
		}
	}

	/** 2. get module status */
	@Override
	public Status status() {
		// 1. AAI_Module status
		if (isAAI_Module(m_module)) {
			return ((AAI_Module) m_module).status();
		}
		// 2. non-AAI_Module status
		return m_status;
	}

	/**
	 * for AAI_Module, we can monitor its process and communicate with it. for
	 * others, we just run it in a separated process and get the output.
	 */
	@Override
	public boolean start() {
		// 1. TODO: DEBUG if module is a AAI_Module
		if (isAAI_Module(m_module)) {
			return ((AAI_Module) m_module).start();
		}
		// 2. TODO: DEBUG if module is a non-AAI_Module
		new Thread(new Runnable() {
			public void run() {
				String command = (jarRunnable() ? "Java -jar " : "")
						+ m_moduleFile + " " + m_options;
				try {
					m_process = Runtime.getRuntime().exec(command);
					status(Status.RUNNING);
					m_process.waitFor();
					BufferedReader reader = new BufferedReader(
							new InputStreamReader(m_process.getInputStream()));
					String output = new String(), line;
					while ((line = reader.readLine()) != null) {
						output += line + "\n";
					}
					output(output);
					status((m_process.exitValue() == 0) ? Status.FINISHED
							: Status.EXCEPTION);
				} catch (Exception e) {
					m_thread = null;
					m_exception = e;
					status(Status.EXCEPTION);
				}
			}
		}).start();

		return true;
	}

	/** TODO: stop the module thread */
	@Override
	public void stop() {
		if (isAAI_Module(m_module)) {
			((AAI_Module) m_module).stop();
		} else {
			m_process.destroy();
			status(Status.STOPPED);
		}
	}

	private Boolean isJar() {
		return m_mainClassName != null;
	}

	private Boolean isAAI() {
		return isAAI_Module(m_mainClass);
	}

	private String mainClassName() {
		return m_mainClassName != null ? m_mainClassName : "";
	}

	/** module file is a runnable jar */
	private Boolean jarRunnable() {
		return isJar() && (m_mainMethod != null);
	}

	/** module file is a runnable jar, and main class implements Runnable */
	private Boolean threadRunnable() {
		return jarRunnable() && Common.subClass(Runnable.class, m_mainClass);
	}

	public String getHelp() {
		try {
			if (isAAI_Module(m_module)) {
				return (String) ModuleLoader.invoke(mainClass(), "help");
			}
			return "no help.";
		} catch (Exception e) {
			return "no help. " + Common.exception(e);
		}
	}

	public String getVersion() {
		try {
			if (isAAI_Module(m_module)) {
				return (String) ModuleLoader.invoke(mainClass(), "version");
			}
			return "no version.";
		} catch (Exception e) {
			return "no version. " + Common.exception(e);
		}
	}

	/**
	 * Module: [moduleName, isAAI, isJar, main_class, jarRunnable,
	 * threadRunnable, moduleFile]
	 */
	@Override
	public String description() {
		return name() + ", " + isAAI() + ", " + isJar() + ", "
				+ mainClassName() + ", " + jarRunnable() + ", "
				+ threadRunnable() + ", " + m_moduleFile;
	}

	public String taskDesc() {
		return fullName() + ", " + owner().name() + ", " + status() + ", "
				+ progress() + "%, " + runningTime();
	}
}