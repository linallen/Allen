package pkgModule;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.reflect.Method;

import pkgCommon.AAI_Module;
import pkgCommon.Common;

/**
 * General module class which<br>
 * 1. can be loaded from file (loadModule()), both local and remote.<br>
 * 2. can make a new copy (copy()).<br>
 * 3. a Module can be: AAI_Module, the main class loaded from a .jar file, or
 * any external file.
 * 
 * @author Allen Lin, 3 Dec 2014
 */
public class Module extends AAI_Module {
	private static final long serialVersionUID = -7360027778759477361L;

	/** module file */
	private String m_moduleFile;

	/**
	 * main class name.<br>
	 * "" means moduleFile is a jar file but has no main class,<br>
	 * null means moduleFile is not a jar file.
	 */
	private String m_mainClassName;

	/** main class (the actual module) */
	private transient Class<?> m_mainClass;

	/** an instance of main class */
	private transient Object m_moduleObj;

	/** main() method of the main class */
	private transient Method m_mainMethod;

	/** process of non-thread-able modules */
	private transient Process m_process;

	/** load module from file */
	public void loadModule(String moduleName, String moduleFile)
			throws Exception {
		name(moduleName);
		m_moduleFile = moduleFile;
		m_mainClassName = ModuleLoader.getMainClassName(moduleFile);
		m_mainClass = ModuleLoader.getMainClass(moduleFile);
		m_moduleObj = m_mainClass.newInstance();
		m_mainMethod = ModuleLoader.getMainMethod(m_mainClass);
	}

	/** module copy */
	public Module copy() throws Exception {
		Module moduleCopy = (Module) Common.deepCopy(this);
		moduleCopy.m_mainClass = m_mainClass;
		moduleCopy.m_moduleObj = ((m_mainClass != null) ? m_mainClass
				.newInstance() : null);
		moduleCopy.m_mainMethod = m_mainMethod;
		return moduleCopy;
	}

	/** set module's name */
	public void name(String name) {
		m_name = name;
		if (isAAI_Module(m_moduleObj)) {
			((AAI_Module) m_moduleObj).name(name);
		}
	}

	/** get main class */
	public Class<?> mainClass() {
		return m_mainClass;
	}

	/** get module object */
	public Object obj() {
		return m_moduleObj;
	}

	@Override
	public boolean isRunning() {
		if (isAAI_Module(m_moduleObj)) {
			return ((AAI_Module) m_moduleObj).isRunning();
		}
		return status() == Status.RUNNING;
	}

	/** pass options to the module. */
	@Override
	public void setOptions(String[] options) throws Exception {
		try {
			m_options = Common.getString(options);
			if (isAAI_Module(m_moduleObj)) {
				((AAI_Module) m_moduleObj).setOptions(options);
				((AAI_Module) m_moduleObj).options(Common.getString(options));
			}
		} catch (Exception e) {
			m_options = "";
		}
	}

	/** 2. get module status */
	@Override
	public Status status() {
		// 1. AAI_Module status
		if (isAAI_Module(m_moduleObj)) {
			return ((AAI_Module) m_moduleObj).status();
		}
		// 2. non-AAI_Module status
		return m_status;
	}

	/**
	 * for AAI_Module, we can monitor its process and communicate with it. for
	 * others, we just run it in a separated process and get the output.
	 */
	@Override
	public boolean start() {
		// 1. TODO: DEBUG if module is a AAI_Module
		if (isAAI_Module(m_moduleObj)) {
			return ((AAI_Module) m_moduleObj).start();
		}
		// 2. TODO: DEBUG if module is a non-AAI_Module
		new Thread(new Runnable() {
			public void run() {
				String command = (jarRunnable() ? "Java -jar " : "")
						+ m_moduleFile + " " + m_options;
				try {
					m_process = Runtime.getRuntime().exec(command);
					status(Status.RUNNING);
					m_process.waitFor();
					BufferedReader reader = new BufferedReader(
							new InputStreamReader(m_process.getInputStream()));
					String output = new String(), line;
					while ((line = reader.readLine()) != null) {
						output += line + "\n";
					}
					output(output);
					status((m_process.exitValue() == 0) ? Status.FINISHED
							: Status.EXCEPTION);
				} catch (Exception e) {
					m_thread = null;
					m_exception = e;
					status(Status.EXCEPTION);
				}
			}
		}).start();

		return true;
	}

	/** TODO: stop the module thread */
	@Override
	public void stop() {
		if (isAAI_Module(m_moduleObj)) {
			((AAI_Module) m_moduleObj).stop();
		} else {
			m_process.destroy();
		}
		status(Status.STOPPED);
	}

	private Boolean isJar() {
		return m_mainClassName != null;
	}

	private Boolean isAAI() {
		return (m_moduleObj != null) && isAAI_Module(m_moduleObj);
	}

	private String mainClassName() {
		return m_mainClassName != null ? m_mainClassName : "";
	}

	/** module file is a runnable jar */
	private Boolean jarRunnable() {
		return isJar() && (m_mainMethod != null);
	}

	/** module file is a runnable jar, and main class implements Runnable */
	private Boolean threadRunnable() {
		return jarRunnable() && Common.subClass(Runnable.class, m_mainClass);
	}

	/**
	 * Module: [moduleName, isAAI, isJar, main_class, jarRunnable,
	 * threadRunnable, moduleFile]
	 */
	@Override
	public String description() {
		return name() + ", " + isAAI() + ", " + isJar() + ", "
				+ mainClassName() + ", " + jarRunnable() + ", "
				+ threadRunnable() + ", " + m_moduleFile;
	}
}