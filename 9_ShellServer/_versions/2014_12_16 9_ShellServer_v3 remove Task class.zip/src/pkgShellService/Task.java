package pkgShellService;

import pkgCommon.AAI_Module;
import pkgModule.Module;

/**
 * A task has an underlying module which will do the job actually. The module
 * can be AAI_Module, general Java runnable jar, any file, or nothing.
 */
public class Task extends AAI_Module {
	private static final long serialVersionUID = 8947371430806170961L;

	/**
	 * underlying module of the task, which can be<br>
	 * (1) AAI_MODULE - AAI_Module<br>
	 * (2) RUNNABLE_CLASS - Java Class implementing Runnable interface<br>
	 * (3) RUNNABLE_JAR - Runnable Jar ("Java -jar jar_file options")<br>
	 * (4) OTHER - others (executeShellCommand("module_file options")
	 */
	private Module m_module;

	/** construct task with [task_name, underlying_module, user] */
	public Task(String taskName, Module module, User user) {
		// 1. initialize task
		name(taskName);
		owner(user);
		updateDirs(user.workDir() + taskName);
		// 2. initialize underlying module
		m_module = module;
		m_module.owner(this);
		m_module.updateDirs(workDir());
		// 3. initialize underlying module's internal module
		if (isAAI_Module(m_module.obj())) {
			AAI_Module aai_module = ((AAI_Module) m_module.obj());
			aai_module.name(taskName);
			aai_module.owner(this); // or user
			aai_module.updateDirs(this.workDir());
		}
	}

	/** get module */
	public Module module() {
		return m_module;
	}

	/** set module */
	public void module(Module module) {
		m_module = module;
	}

	/** underlying module updates its progress */
	@Override
	public void notifyProgress(Object child, int progress) {
		// update task's progress with underlying module's progress
		progress(progress);
	}

	/** pass options to the module. */
	@Override
	public void setOptions(String[] options) throws Exception {
		m_module.setOptions(options);
	}

	@Override
	public String options() {
		return m_module.options();
	}

	@Override
	public boolean isRunning() {
		return module().isRunning();
	}

	/** start the task */
	@Override
	public boolean start() {
		return m_module.start();
	}

	/** stop the task */
	@Override
	public void stop() {
		m_module.stop();
	}

	/** get task's running status */
	@Override
	public Status status() {
		if (isAAI_Module(m_module.obj())) {
			return ((AAI_Module) m_module.obj()).status();
		}
		return super.status();
	}

	/**
	 * Task: [task_name, module_name, user_name, status, progress, running_time,
	 * creation_time]
	 */
	@Override
	public String description() {
		return name() + ", " + m_module.name() + ", " + owner().name() + ", "
				+ status() + ", " + progress() + "%, " + runningTime() + ", "
				+ m_creationTime;
	}
}