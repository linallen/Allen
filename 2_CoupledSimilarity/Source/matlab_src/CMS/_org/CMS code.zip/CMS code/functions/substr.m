fuction D = substr(D,ch)

