function dis=dis_cluster(dis_matrix,cluster_i,s)
dis=min(dis_matrix(s,cluster_i));
end