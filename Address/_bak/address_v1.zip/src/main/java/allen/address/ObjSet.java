package allen.address;

import java.util.HashSet;

/** a general set */
public class ObjSet {
	public HashSet<Object> m_objSet = new HashSet<Object>();

	/** return the set[] */
	public HashSet<Object> get() {
		return m_objSet;
	}

	/** add an object to the set */
	public void add(Object obj) {
		m_objSet.add(obj);
	}
}