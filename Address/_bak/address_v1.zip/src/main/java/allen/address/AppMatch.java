package allen.address;

import allen.base.common.AAI_IO;
import allen.base.common.Common;
import allen.base.module.AAI_Module;

public class AppMatch extends AAI_Module {
	private static final long serialVersionUID = 7384874700719711854L;

	/** 1. global keyword set[] */
	public KwdSet m_kwdSet = new KwdSet();

	/** 2. global address set[] */
	public ObjSet m_addrSet = new ObjSet();

	/** <char ch, int pos, kwds[]>, kwds[] contain 'ch' at pos. */
	CharPosKwds m_charPosKwds;

	/**
	 * input: addrs.csv = {ADDRESS_DETAIL_PID[0], BUILDING_NAME[1],
	 * FLAT_NUMBER[2], NUMBER_FIRST[3], NUMBER_FIRST_SUFFIX[4], NUMBER_LAST[5],
	 * NUMBER_LAST_SUFFIX[6], STREET_NAME[7], STREET_TYPE_CODE[8],
	 * STREET_SUFFIX_TYPE[9], LOCALITY_NAME[10], STATE_ABBREVIATION[11],
	 * POSTCODE[12], ADDRESS[13]}
	 */
	public void mainProc(String addrsCSV) {
		// Phase 1. Building Indexes from Address Book
		String buf = AAI_IO.readFile(addrsCSV);
		buf = buf.replace("\r", "");
		String lines[] = buf.split("\n");
		buf = "";
		for (int i = 1; i < lines.length; i++) {
			progress(i + 1, lines.length);
			String items[] = lines[i].trim().replaceAll(" +", " ").split(",");
			// 1.1 load & parse keywords to global keyword set[]
			String bldgName = items[1];
			m_kwdSet.add(bldgName);
			String flatNum = items[2];
			m_kwdSet.add(flatNum);
			String numFirst = items[3];
			String numFirstSuffix = items[4];
			m_kwdSet.add(numFirst + numFirstSuffix);
			String numLast = items[5];
			String numLastSuffix = items[6];
			m_kwdSet.add(numLast + numLastSuffix);
			// add street numbers[] to this address's keywords[]
			Common.Assert(!numFirst.isEmpty());
			if (!numLast.isEmpty()) {
				int numFirstInt = Integer.parseInt(numFirst);
				int numLastInt = Integer.parseInt(numLast);
				Common.Assert(numFirstInt <= numLastInt);
				for (int streetNum = numFirstInt + 1; streetNum < numLastInt; streetNum++) {
					m_kwdSet.add(streetNum + "");
				}
			}
			// add street numbers[] too
			String StreetName = items[7];
			m_kwdSet.add(StreetName);
			String StreetType = items[8];
			m_kwdSet.add(StreetType);
			String StreetSuffix = items[9];
			m_kwdSet.add(StreetSuffix);
			String LocalityName = items[10];
			m_kwdSet.add(LocalityName);
			String StateAbbr = items[11];
			m_kwdSet.add(StateAbbr);
			String PostCode = items[12];
			m_kwdSet.add(PostCode);
			// address
			flatNum += flatNum.isEmpty() ? "" : "/";
			String streetNum = (numFirst + numFirstSuffix) + (numLast.isEmpty() ? "" : "-" + numLast + numLastSuffix);
			StreetName += StreetSuffix.isEmpty() ? "" : (" " + StreetSuffix);
			String AddressDesc = flatNum + streetNum + " " + StreetName + " " + StreetType + " " + LocalityName + " "
					+ StateAbbr + " " + PostCode + (bldgName.isEmpty() ? "" : " (" + bldgName + ")");
			buf += AddressDesc + "\n";

			// 1.2 load & parse addresses to global address set[]
		}
		AAI_IO.saveFile(addrsCSV + ".addrs.txt", buf);

		// Setp
	}

	public static void main(String[] args) throws Exception {
		AppMatch appMatch = new AppMatch();
		appMatch.debug(true);
		appMatch.mainProc("C:/Allen/Dropbox/2016_11_06 Address/address_v2.csv");
		System.out.println("\nAll done!");
	}
}
