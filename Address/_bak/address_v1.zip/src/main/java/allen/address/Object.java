package allen.address;

public class Object {

}
