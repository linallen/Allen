package allen.address;

import java.util.HashMap;

public class KwdSet {
	private HashMap<String, Kwd> m_kwdSet = new HashMap<String, Kwd>();

	private void addKwd(String kwdStr) {
		kwdStr = kwdStr.intern();
		if (get(kwdStr) == null) {
			m_kwdSet.put(kwdStr, new Kwd(kwdStr));
		}
	}

	public void add(String kwdString) {
		kwdString = kwdString.trim().replaceAll(" +", " ");
		String kwdStrs[] = kwdString.split(" ");
		for (String kwdStr : kwdStrs) {
			addKwd(kwdStr);
		}
	}

	public Kwd get(String kwdStr) {
		return m_kwdSet.get(kwdStr);
	}

	// TODO
	public String toString() {
		String buf = new String();
		return buf;
	}
}