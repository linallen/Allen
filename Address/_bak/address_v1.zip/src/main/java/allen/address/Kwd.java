package allen.address;

/** keyword object */
public class Kwd {
	private String m_kwd;

	public Kwd(String kwd) {
		m_kwd = kwd.intern();
	}

	public String get() {
		return m_kwd;
	}
}