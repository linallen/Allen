package allen.address;

import java.util.HashSet;

/** a kwd set */
public class KwdSet {
	public HashSet<Addr> m_kwdSet = new HashSet<Addr>();

	public HashSet<Addr> get() {
		return m_kwdSet;
	}

	/** add a kwd to the set */
	public void add(Addr kwd) {
		m_kwdSet.add(kwd);
	}
}