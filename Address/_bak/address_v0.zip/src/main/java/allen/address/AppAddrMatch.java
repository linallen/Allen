package allen.address;

public class AppAddrMatch {
	/** 1. global kwd set[] */
	public KwdSet m_kwdSet = new KwdSet();

	/** 1. global address set[] */
	public AddrSet m_addrSet = new AddrSet();

	
	/** <char ch, int pos, kwds[]>, kwds[] contain 'ch' at pos. */
	CharPosKwds m_charPosKwds;
	// public
}
