package allen.address;

import java.util.HashSet;

/** an address set */
public class AddrSet {
	public HashSet<Addr> m_addrSet = new HashSet<Addr>();

	public HashSet<Addr> get() {
		return m_addrSet;
	}

	/** add a kwd to the set */
	public void add(Addr addr) {
		m_addrSet.add(addr);
	}
}