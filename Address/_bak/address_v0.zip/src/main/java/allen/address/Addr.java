package allen.address;

public class Addr {

}
