package pkgCsvConverter;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

import org.apache.commons.io.FilenameUtils;

import pkgCommon.AAI_Module;
import pkgCommon.Common;
import pkgCommon.Timer;

/**
 * Convert and/or split a CSV file to a (list of) ARFF or CSV file(s).
 * <p>
 * <b>Syntax</b>:<br>
 * Java -jar CsvConverter.jar -i input_csv -o output_file [-D id_num] [[-r
 * row_num] | [-s sub_num]] [-v val_num] [-S] [-C]
 * <p>
 * <ul>
 * <li><i>-i input_csv<i>: the CSV file to convert and/or split.</li>
 * <li><i>-o output_file<i>: the output file(s).</li>
 * <li><i>-D id_num<i>: number of the first left-most columns are ID columns.</li>
 * <li><i>-r row_num<i>: the max number of instances a sub file has. Inf by
 * default (no splitting).</li>
 * <li><i>-s sub_num<i>: the number of sub files. 1 by default (no splitting).</li>
 * <li><i>-v val_num<i>: max number of values a Nominal feature has. 100 by
 * default.</li>
 * <li><i>-S<i>: shuffle the instances, otherwise not.</li>
 * <li><i>-C<i>: output CSV file(s), otherwise output ARFF file(s).</li>
 * </ul>
 * 
 * @author Allen Lin, 2 Oct 2014
 */
public class CsvConverter extends AAI_Module {
	private static final long serialVersionUID = -7789190482212675338L;

	/** [input] the CSV file to convert and/or split */
	private String m_inputCSV;

	/** number of ID columns */
	private int m_idNum = 0;

	/** the max # of instances a sub file has. Inf by default (no splitting) */
	private int m_rowNum = Integer.MAX_VALUE;

	/** the number of sub data files. 1 by default (no splitting) */
	private int m_subNum = 1;
	/**
	 * the maximum number of distinct values a nominal feature has. If a nominal
	 * has more distinct values than the limit, it is considered as STRING type.
	 */
	private int m_valNum = 100;

	/** the instances will be shuffled or not? */
	private boolean m_shuffle;

	/** the output sub data files are CSVs or ARFFs? */
	private boolean m_outputCSV;

	/**
	 * the output sub data files. If the input_csv is split into multiple files,
	 * the sub-files will be named as output_file��s name + ��_index�� + suffix.
	 * E.g., output_file is ��out.csv��, then sub-files are ��out_1.csv��,
	 * ��out_2.csv��, ��
	 */
	private String m_outputFile;

	/** the number of instances in the input CSV file */
	private int m_instNum;
	/** features or attributes of the input CSV file */
	private Feature[] m_features;
	/** the ARFF header generated from the input CSV file */
	private String m_arffHeader = new String();
	/** the mapping of [inst_id, sub_file_id] */
	private HashMap<Integer, Integer> m_mapInstSub;
	/** [output] the sub-files */
	private String[] m_subFiles;

	/** standardize string from That's fine. --> 'That\'s fine.' */
	private static String stdString(String value) {
		value.replaceAll("''", "\\''");
		if (value.contains(" ")) {
			value = "\'" + value + "\'";
		}
		return value;
	}

	// -i input.csv [[-r row_num] | [-s sub_num]] [-S] [-C] [-o output_dir]
	public void setOptions(String[] options) throws Exception {
		// -i input.csv
		m_inputCSV = Common.getOption("i", options);
		if (!Common.fileExist(m_inputCSV)) {
			throw new Exception("input .csv " + Common.quote(m_inputCSV)
					+ " does not exist.");
		}
		// Add by Allen on 9 Dec 2014 for progress updating.
		// CsvConverter does two scans over m_inputCSV
		m_total = Common.getFileSize(m_inputCSV) * 2;

		// -o output_file
		m_outputFile = Common.getOption("o", options);
		if (m_outputFile.isEmpty()) {
			throw new Exception("-o output_file is missing.");
		}
		// [-D id_num]
		m_idNum = Common.getOptionInt("D", options, m_idNum);
		// [[-r row_num] | [-s sub_num]]
		String rowNum = Common.getOption("r", options);
		String subNum = Common.getOption("s", options);
		if ((rowNum.length() > 0) && (subNum.length() > 0)) {
			throw new Exception("-r and -s are mutually exclusive options.");
		}
		if (rowNum.length() > 0) {
			m_rowNum = Integer.parseInt(rowNum);
			m_subNum = 0;
		}
		if (subNum.length() > 0) {
			m_subNum = Integer.parseInt(subNum);
			m_rowNum = 0;
		}
		// [-v val_num]
		m_valNum = Common.getOptionInt("r", options, m_valNum);
		// [-S] randomize the data rows
		m_shuffle = Common.getOptionBool("S", options);
		// [-C]
		m_outputCSV = Common.getOptionBool("C", options);
	}

	private String[] getFtrNames(String line) throws Exception {
		String[] ftrNames = line.split(",");
		for (int i = 0; i < ftrNames.length; i++) {
			if (ftrNames[i].isEmpty()) {
				throw new Exception("feature[" + (i + 1) + "] has no name.");
			}
		}
		if (ftrNames.length <= 0) {
			throw new Exception("Did not find any feature name.");
		}
		return ftrNames;
	}

	/** generate ARFF features[] from input CSV */
	@SuppressWarnings("resource")
	private int genFeatures() throws Exception {
		BufferedReader br = new BufferedReader(new FileReader(m_inputCSV));
		// 1. initialize features[] with the first header row
		String line = br.readLine();
		m_finished += line.length() + 2;
		String[] ftrNames = getFtrNames(line);
		m_features = new Feature[ftrNames.length];
		for (int i = 0; i < ftrNames.length; i++) {
			Common.Assert(ftrNames[i].length() > 0);
			m_features[i] = new Feature(ftrNames[i], m_valNum);
		}
		// set ID features to be STRING
		for (int i = 0; i < m_idNum; i++) {
			m_features[i].setTypeString();
		}
		// 2. parse data rows
		int instNum = 0;
		for (; (line = br.readLine()) != null;) {
			m_finished += line.length() + 2;
			progress(m_finished, m_total);
			String[] values = line.split(",");
			if (values.length > m_features.length) {
				throw new Exception("instance " + (instNum + 1)
						+ " contains too many values. " + Common.quote(line));
			}
			for (int j = 0; j < values.length; j++) {
				if ((values[j].length() > 0) && (!values[j].equals("?"))) {
					// only add non-missing values to features
					m_features[j].addValue(stdString(values[j]));
				}
			}
			instNum++;
		}
		br.close();
		return instNum;
	}

	/** generate ARFF header */
	private int genArffHeader() throws Exception {
		Timer timer = new Timer();
		outLog("Generating ARFF headers... "
				+ "(nominal features having more than " + m_valNum
				+ " distinct values will be regarded as STRING type.)");
		int instNum = genFeatures();
		// "@attribute"
		String attr = new String();
		for (Feature ftr : m_features) {
			attr += ("@attribute " + ftr.toString() + "\n");
		}
		// ARFF header
		String relation = stdString((new File(m_inputCSV)).getName()
				.replaceAll("\\.[cC][sS][vV]$", ""));
		m_arffHeader = "@relation " + relation + "\n\n" + attr + "\n@data";
		outLog("Done. " + instNum + " instances. " + timer);
		return instNum;
	}

	@Override
	public void run() {
		try {
			status(Status.RUNNING);
			convert();
			status(Status.FINISHED);
		} catch (Exception e) {
			m_exception = e;
			status(Status.EXCEPTION);
			return;
		}
	}

	public String[] getSubFiles() {
		return m_subFiles;
	}

	/**
	 * convert and/or split a CSV file to a (list of) ARFF or CSV file(s).<br>
	 * options: -i input_csv -o output_file [-D id_num] [[-r row_num] | [-s
	 * sub_num]] [-v val_num] [-S] [-C]
	 */
	private void convert() throws Exception {
		// 1. get instance number and generate ARFF header (if needed)
		m_instNum = m_outputCSV ? Common.getInstNum(m_inputCSV)
				: genArffHeader();
		// 2. determine the number of sub files and the max rows they have
		if (m_subNum == 0) {
			Common.Assert(m_rowNum != 0);
			m_subNum = (int) Math.ceil(1. * m_instNum / m_rowNum);
		}
		if (m_rowNum == 0) {
			m_rowNum = (int) Math.ceil(1. * m_instNum / m_subNum);
		}
		// 3. generate mapping of which instance goes to which sub file
		ArrayList<Integer> instIdLst = new ArrayList<Integer>(m_instNum);
		for (int i = 0; i < m_instNum; i++) {
			instIdLst.add(i);
		}
		if (m_shuffle) {
			Collections.shuffle(instIdLst); // shuffle instances?
		}
		m_mapInstSub = new HashMap<Integer, Integer>(m_instNum);
		for (int i = 0; i < instIdLst.size(); i++) {
			m_mapInstSub.put(instIdLst.get(i), i / m_rowNum);
		}
		// 4. distribute instances to sub files according to the mapping
		BufferedReader br = new BufferedReader(new FileReader(m_inputCSV));
		String csvHeader = br.readLine(); // the title row
		m_finished += csvHeader.length() + 2;
		m_subFiles = new String[m_subNum];
		BufferedWriter[] bw = new BufferedWriter[m_subNum];
		//
		String outputName = FilenameUtils.getBaseName(m_outputFile);
		String outputExt = FilenameUtils.getExtension(m_outputFile);
		String outputPath = FilenameUtils.getFullPath(m_outputFile);
		// TODO: testing update progress
		for (int subNo = 0; subNo < m_subNum; subNo++) {
			m_subFiles[subNo] = outputPath + outputName
					+ (m_subNum > 1 ? "_" + subNo : "") + "." + outputExt;
			bw[subNo] = new BufferedWriter(new FileWriter(m_subFiles[subNo]));
			// write CSV/ARFF header
			bw[subNo].write((m_outputCSV ? csvHeader : m_arffHeader) + "\n");
		}
		// distribute instances to sub files
		for (int instNo = 0; instNo < m_instNum; instNo++) {
			String line = br.readLine();
			m_finished += line.length() + 2;
			Common.Assert(line != null);
			int subNo = m_mapInstSub.get(instNo);
			if (m_outputCSV) {
				// CSV data lines
				bw[subNo].write(line);
			} else {
				// ARFF data lines
				String[] values = line.split(",");
				for (int i = 0; i < m_features.length; i++) {
					if ((i < values.length) && (values[i].length() > 0)) {
						bw[subNo].write(stdString(values[i]));
					} else {
						bw[subNo].write("?");
					}
					bw[subNo].write((i < m_features.length - 1) ? "," : "");
				}
				progress(m_finished, m_total);
			}
			bw[subNo].newLine();
		}
		for (int subNo = 0; subNo < m_subNum; subNo++) {
			bw[subNo].close();
		}
		br.close();
	}

	/**
	 * Java -jar cc.jar -i input.csv [[-r row_num] | [-s sub_num]] [-v val_num]
	 * [-S] [-C] [-o output_dir]
	 */
	public static void main(String[] args) throws Exception {
		CsvConverter module = new CsvConverter();
		System.out.println("\n" + CsvConverter.version());
		if (args.length == 0) {
			System.out.println(CsvConverter.help() + "\n");
			return;
		}
		module.setOptions(args);
		module.start();
		module.join();
	}

	public static String help() {
		return "Function:\nConvert and/or split a CSV file to a (list of) ARFF or CSV file(s).\n\n"
				+ "Syntax:\nJava -jar cc.jar"
				+ " -i input_csv -o output_file [[-r row_num] | [-s sub_num]] [-v val_num] [-S] [-C]\n\n"
				+ "-i input_csv: the CSV file to convert and/or split.\n"
				+ "-o output_file: the output file(s). If the input_csv is split into multiple files, "
				+ "the sub-files will be named as output_file��s name + \"_index\" + suffix. "
				+ "E.g., output_file is \"out.csv\", then sub-files are \"out_1.csv\", \"out_2.csv\", ��\n"
				+ "-D id_num: number of the first left-most columns are ID columns.\n"
				+ "-r row_num: the maximum number of instances each sub file has. Inf by default (no splitting).\n"
				+ "-s sub_num: the number of sub files. 1 by default (no splitting).\n"
				+ "-v val_num: max number of values a Nominal feature has. 100 by default.\n"
				+ "-S: shuffle the instances, otherwise not.\n"
				+ "-C: output CSV file(s), otherwise output ARFF file(s).\n";
	}

	public static String version() {
		return "Latest modified on 5 Jan 2015, update status\n"
				+ "V0.2.0.2, migrating to AAI Platform, 9 Dec 2014 Allen.\n"
				+ "V0.2.0.1, added -o output_file option, 17 Nov 2014 Allen.\n"
				+ "V0.2, Convert and/or split a CSV file to a (list of) ARFF or CSV file(s)\n"
				+ "V0.1, Jar file created on 11 Sep 2014.\n"
				+ "V0.1, Convert a CSV file into a (list of) ARFF file(s), Created on 2 June 2014 by Allen Lin.\n";
	}
}